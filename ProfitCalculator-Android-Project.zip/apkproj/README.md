# Profit Calculator Android app

This Android Studio project wraps the local Profit Calculator HTML app in an Android WebView. The calculator runs offline; it does not need internet access for calculations.

## Build an APK

### Android Studio
1. Open this folder in Android Studio.
2. Allow Gradle sync and install any requested Android SDK components.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

### Build without Android Studio using GitHub Actions
1. Create a new repository on GitHub and upload the contents of this folder (not the ZIP itself).
2. Open the repository's **Actions** tab.
3. Choose **Build Android APK**, then **Run workflow** (or push to `main`).
4. Open the completed workflow run and download the `ProfitCalculator-debug-apk` artifact. Unzip it to get `app-debug.apk`.

The debug APK is for personal testing and sideloading. A release APK for public distribution should be signed with your own release key.
